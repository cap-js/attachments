const config = {
    testTimeout: 42222,
    testMatch: ['**/*.test.js']
  }
  
module.exports = config