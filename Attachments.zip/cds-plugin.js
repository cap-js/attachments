require('./lib/plugin')

// Entry point for separate object store instance case
require('./lib/mtx/server')
